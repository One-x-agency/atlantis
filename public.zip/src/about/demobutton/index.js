import react from "react";
import './demobutton.scss';
export default function Demobutton () {
    return (
        <div>
          

          <div>
            <button type="button" className="button roundedfull">SUBMIT</button>
             
          </div>


        </div>
    )
}